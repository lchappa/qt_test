var classfenetre =
[
    [ "~fenetre", "classfenetre.html#ae0e6866bb8bd4824291a6a43428611d0", null ],
    [ "changer_url", "classfenetre.html#a1e6e9f150c884f9f9ac83eaba76a1c90", null ],
    [ "choixcouleur", "classfenetre.html#a211d78b07b1e8da2cd7372389d07f6d3", null ],
    [ "envoyer_lum", "classfenetre.html#a2008b843cae9b5b7bdd5465d8452589b", null ],
    [ "envoyer_txt", "classfenetre.html#aa8daaed5ba7784d460d46d590ff1ed9f", null ],
    [ "on_send_brightness_sliderMoved", "classfenetre.html#a32cc35a8ed1efcd947b9c682d5b8159c", null ],
    [ "telecharger_brightness", "classfenetre.html#a63dbf2c09d0fd406cb7f3bd5454bd638", null ]
];