var classpixelix =
[
    [ "brightness", "classpixelix.html#a112bfa6a8780e99e144019c7360d0a3a", null ],
    [ "envoyer_lum", "classpixelix.html#a3b540346a06c05162d346e03246327d2", null ],
    [ "envoyer_txt", "classpixelix.html#acea7d35c637cd98ac746a2103c12a7d7", null ],
    [ "get", "classpixelix.html#aefbfcfc6dabc456605b218559b7b1b24", null ],
    [ "get_brightness", "classpixelix.html#abfa49886b890d19d7714ec0285ed9954", null ],
    [ "get_json_brightness", "classpixelix.html#a2e137faf25a8eec79a4efdbb5be055e3", null ],
    [ "post", "classpixelix.html#aa433a23137db8b2db43c5402d52d1a46", null ],
    [ "set_url", "classpixelix.html#a195b69d622526f8c77450a9a6f0c6dac", null ],
    [ "text", "classpixelix.html#ac01a5c7cb6114537780caee110850995", null ]
];