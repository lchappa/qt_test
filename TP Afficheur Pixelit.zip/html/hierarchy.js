var hierarchy =
[
    [ "pixelix", "classpixelix.html", null ],
    [ "QMainWindow", null, [
      [ "fenetre", "classfenetre.html", null ]
    ] ]
];