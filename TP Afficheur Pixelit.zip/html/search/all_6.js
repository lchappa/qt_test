var searchData=
[
  ['on_5fsend_5fbrightness_5fslidermoved_0',['on_send_brightness_sliderMoved',['../classfenetre.html#a32cc35a8ed1efcd947b9c682d5b8159c',1,'fenetre']]]
];
