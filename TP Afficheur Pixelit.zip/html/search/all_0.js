var searchData=
[
  ['brightness_0',['brightness',['../classpixelix.html#a112bfa6a8780e99e144019c7360d0a3a',1,'pixelix']]]
];
