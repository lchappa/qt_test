var searchData=
[
  ['telecharger_5fbrightness_0',['telecharger_brightness',['../classfenetre.html#a63dbf2c09d0fd406cb7f3bd5454bd638',1,'fenetre']]],
  ['text_1',['text',['../classpixelix.html#ac01a5c7cb6114537780caee110850995',1,'pixelix']]]
];
