var searchData=
[
  ['envoyer_5flum_0',['envoyer_lum',['../classfenetre.html#a2008b843cae9b5b7bdd5465d8452589b',1,'fenetre::envoyer_lum()'],['../classpixelix.html#a3b540346a06c05162d346e03246327d2',1,'pixelix::envoyer_lum()']]],
  ['envoyer_5ftxt_1',['envoyer_txt',['../classfenetre.html#aa8daaed5ba7784d460d46d590ff1ed9f',1,'fenetre::envoyer_txt()'],['../classpixelix.html#acea7d35c637cd98ac746a2103c12a7d7',1,'pixelix::envoyer_txt()']]]
];
